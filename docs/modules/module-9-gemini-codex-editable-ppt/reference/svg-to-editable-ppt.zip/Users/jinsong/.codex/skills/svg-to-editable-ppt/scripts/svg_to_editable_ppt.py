#!/usr/bin/env python3

import argparse
import math
import re
import unicodedata
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE, MSO_CONNECTOR_TYPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml import parse_xml
from pptx.oxml.ns import nsdecls, qn
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt


SVG_NS = "http://www.w3.org/2000/svg"
NS = f"{{{SVG_NS}}}"
SLIDE_W = 1920.0
SLIDE_H = 1080.0
PPT_W = Inches(13.333333)
PPT_H = Inches(7.5)
EMU_PER_PX_X = PPT_W / SLIDE_W
EMU_PER_PX_Y = PPT_H / SLIDE_H
PATH_TOKEN_RE = re.compile(
    r"[AaCcHhLlMmQqSsTtVvZz]|[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?"
)
CSS_RULE_RE = re.compile(r"(?s)([^{}]+)\{([^{}]+)\}")
RGB_RE = re.compile(r"rgba?\(([^)]+)\)")


def px_to_emu_x(value):
    return int(round(float(value) * EMU_PER_PX_X))


def px_to_emu_y(value):
    return int(round(float(value) * EMU_PER_PX_Y))


def px_to_pt(value):
    return float(value) / 2.0


def clamp(value, low, high):
    return max(low, min(high, value))


def clamp01(value):
    return max(0.0, min(1.0, float(value)))


def normalize_text(text):
    return " ".join((text or "").split())


def parse_float(value, default=0.0):
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


def parse_fraction(value, default=0.0):
    if value is None:
        return default
    text = str(value).strip()
    try:
        if text.endswith("%"):
            return clamp01(float(text[:-1]) / 100.0)
        return clamp01(float(text))
    except ValueError:
        return default


def parse_translate(transform):
    if not transform:
        return 0.0, 0.0
    match = re.search(r"translate\(\s*([-\d.]+)(?:[,\s]+([-\d.]+))?\s*\)", transform)
    if not match:
        return 0.0, 0.0
    tx = float(match.group(1))
    ty = float(match.group(2) or 0.0)
    return tx, ty


def parse_path_line(d):
    nums = [float(part) for part in re.findall(r"[-+]?(?:\d*\.\d+|\d+)", d or "")]
    if len(nums) < 4:
        return None
    return nums[0], nums[1], nums[2], nums[3]


def parse_path_tokens(d):
    return PATH_TOKEN_RE.findall(d or "")


def is_path_command(token):
    return len(token) == 1 and token.isalpha()


def hex_to_rgb(value):
    value = (value or "").strip()
    if not value or value == "none":
        return None
    if value.startswith("#"):
        value = value[1:]
    if len(value) == 3:
        value = "".join(ch * 2 for ch in value)
    if len(value) != 6:
        return None
    return tuple(int(value[i : i + 2], 16) for i in range(0, 6, 2))


def parse_rgb_color(value):
    text = (value or "").strip()
    if not text or text == "none":
        return None, 1.0

    match = RGB_RE.fullmatch(text)
    if match:
        parts = [part.strip() for part in match.group(1).split(",")]
        if len(parts) not in {3, 4}:
            return None, 1.0
        rgb = []
        for part in parts[:3]:
            try:
                if part.endswith("%"):
                    rgb.append(int(round(float(part[:-1]) * 2.55)))
                else:
                    rgb.append(int(round(float(part))))
            except ValueError:
                return None, 1.0
        alpha = 1.0
        if len(parts) == 4:
            try:
                alpha = clamp01(float(parts[3]))
            except ValueError:
                alpha = 1.0
        return tuple(max(0, min(255, channel)) for channel in rgb), alpha

    rgb = hex_to_rgb(text)
    return rgb, 1.0


def parse_style_attr(style):
    props = {}
    for chunk in (style or "").split(";"):
        if ":" not in chunk:
            continue
        key, value = chunk.split(":", 1)
        props[key.strip().lower()] = value.strip()
    return props


def rgb_to_hex(rgb):
    return "".join(f"{channel:02X}" for channel in rgb)


def avg_stop_color(stops):
    if not stops:
        return (248, 250, 252)
    total = 0.0
    r = g = b = 0.0
    last_offset = 0.0
    for idx, stop in enumerate(stops):
        offset = stop["offset"]
        if idx == 0:
            weight = max(0.0001, stops[1]["offset"] - offset) if len(stops) > 1 else 1.0
        else:
            weight = max(0.0001, offset - last_offset)
        last_offset = offset
        opacity = stop.get("opacity", 1.0)
        total += weight * opacity
        r += stop["rgb"][0] * weight * opacity
        g += stop["rgb"][1] * weight * opacity
        b += stop["rgb"][2] * weight * opacity
    if total <= 0:
        return stops[-1]["rgb"]
    return (int(round(r / total)), int(round(g / total)), int(round(b / total)))


def cubic_bezier_point(p0, p1, p2, p3, t):
    mt = 1.0 - t
    return (
        mt**3 * p0[0] + 3 * mt * mt * t * p1[0] + 3 * mt * t * t * p2[0] + t * t * t * p3[0],
        mt**3 * p0[1] + 3 * mt * mt * t * p1[1] + 3 * mt * t * t * p2[1] + t * t * t * p3[1],
    )


def quadratic_bezier_point(p0, p1, p2, t):
    mt = 1.0 - t
    return (
        mt * mt * p0[0] + 2 * mt * t * p1[0] + t * t * p2[0],
        mt * mt * p0[1] + 2 * mt * t * p1[1] + t * t * p2[1],
    )


def approx_cubic_bezier(p0, p1, p2, p3, segments=12):
    return [cubic_bezier_point(p0, p1, p2, p3, i / segments) for i in range(1, segments + 1)]


def approx_quadratic_bezier(p0, p1, p2, segments=10):
    return [quadratic_bezier_point(p0, p1, p2, i / segments) for i in range(1, segments + 1)]


def vector_angle(u, v):
    umag = math.hypot(u[0], u[1]) or 1.0
    vmag = math.hypot(v[0], v[1]) or 1.0
    dot = clamp((u[0] * v[0] + u[1] * v[1]) / (umag * vmag), -1.0, 1.0)
    sign = 1.0 if (u[0] * v[1] - u[1] * v[0]) >= 0 else -1.0
    return sign * math.acos(dot)


def approx_arc_points(start, rx, ry, rotation, large_arc, sweep, end):
    x1, y1 = start
    x2, y2 = end
    rx = abs(rx)
    ry = abs(ry)
    if rx == 0 or ry == 0 or (x1 == x2 and y1 == y2):
        return [end]

    phi = math.radians(rotation % 360.0)
    cos_phi = math.cos(phi)
    sin_phi = math.sin(phi)

    dx2 = (x1 - x2) / 2.0
    dy2 = (y1 - y2) / 2.0
    x1p = cos_phi * dx2 + sin_phi * dy2
    y1p = -sin_phi * dx2 + cos_phi * dy2

    lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
    if lam > 1.0:
        scale = math.sqrt(lam)
        rx *= scale
        ry *= scale

    rx2 = rx * rx
    ry2 = ry * ry
    x1p2 = x1p * x1p
    y1p2 = y1p * y1p

    denom = rx2 * y1p2 + ry2 * x1p2
    if denom == 0:
        return [end]

    sign = -1.0 if large_arc == sweep else 1.0
    sq = max(0.0, (rx2 * ry2 - rx2 * y1p2 - ry2 * x1p2) / denom)
    coef = sign * math.sqrt(sq)
    cxp = coef * (rx * y1p / ry)
    cyp = coef * (-ry * x1p / rx)

    cx = cos_phi * cxp - sin_phi * cyp + (x1 + x2) / 2.0
    cy = sin_phi * cxp + cos_phi * cyp + (y1 + y2) / 2.0

    start_vec = ((x1p - cxp) / rx, (y1p - cyp) / ry)
    end_vec = ((-x1p - cxp) / rx, (-y1p - cyp) / ry)
    theta1 = vector_angle((1.0, 0.0), start_vec)
    delta = vector_angle(start_vec, end_vec)
    if not sweep and delta > 0:
        delta -= 2.0 * math.pi
    elif sweep and delta < 0:
        delta += 2.0 * math.pi

    segments = max(6, int(math.ceil(abs(delta) / (math.pi / 8.0))))
    points = []
    for i in range(1, segments + 1):
        theta = theta1 + delta * (i / segments)
        xp = rx * math.cos(theta)
        yp = ry * math.sin(theta)
        x = cos_phi * xp - sin_phi * yp + cx
        y = sin_phi * xp + cos_phi * yp + cy
        points.append((x, y))
    return points


def parse_svg_path(d):
    tokens = parse_path_tokens(d)
    if not tokens:
        return []

    contours = []
    idx = 0
    cmd = None
    cur = (0.0, 0.0)
    start = None
    points = []
    last_cubic_ctrl = None
    last_quad_ctrl = None

    def finish_contour(closed):
        nonlocal points, start
        if len(points) > 1:
            contours.append({"points": points[:], "closed": closed})
        points = []
        start = None

    def next_num():
        nonlocal idx
        value = float(tokens[idx])
        idx += 1
        return value

    while idx < len(tokens):
        token = tokens[idx]
        if is_path_command(token):
            cmd = token
            idx += 1
        if cmd is None:
            break

        absolute = cmd.isupper()
        op = cmd.upper()

        if op == "Z":
            if start is not None:
                cur = start
                finish_contour(True)
            last_cubic_ctrl = None
            last_quad_ctrl = None
            cmd = None
            continue

        if idx >= len(tokens):
            break

        if op == "M":
            x = next_num()
            y = next_num()
            if not absolute:
                x += cur[0]
                y += cur[1]
            if points:
                finish_contour(False)
            cur = (x, y)
            start = cur
            points = [cur]
            last_cubic_ctrl = None
            last_quad_ctrl = None
            cmd = "L" if absolute else "l"
            continue

        if start is None:
            start = cur
            points = [cur]

        if op == "L":
            x = next_num()
            y = next_num()
            if not absolute:
                x += cur[0]
                y += cur[1]
            cur = (x, y)
            points.append(cur)
            last_cubic_ctrl = None
            last_quad_ctrl = None
            continue

        if op == "H":
            x = next_num()
            if not absolute:
                x += cur[0]
            cur = (x, cur[1])
            points.append(cur)
            last_cubic_ctrl = None
            last_quad_ctrl = None
            continue

        if op == "V":
            y = next_num()
            if not absolute:
                y += cur[1]
            cur = (cur[0], y)
            points.append(cur)
            last_cubic_ctrl = None
            last_quad_ctrl = None
            continue

        if op == "C":
            x1 = next_num()
            y1 = next_num()
            x2 = next_num()
            y2 = next_num()
            x = next_num()
            y = next_num()
            if not absolute:
                x1 += cur[0]
                y1 += cur[1]
                x2 += cur[0]
                y2 += cur[1]
                x += cur[0]
                y += cur[1]
            end = (x, y)
            points.extend(approx_cubic_bezier(cur, (x1, y1), (x2, y2), end))
            cur = end
            last_cubic_ctrl = (x2, y2)
            last_quad_ctrl = None
            continue

        if op == "S":
            x2 = next_num()
            y2 = next_num()
            x = next_num()
            y = next_num()
            if last_cubic_ctrl is None:
                x1, y1 = cur
            else:
                x1 = 2 * cur[0] - last_cubic_ctrl[0]
                y1 = 2 * cur[1] - last_cubic_ctrl[1]
            if not absolute:
                x2 += cur[0]
                y2 += cur[1]
                x += cur[0]
                y += cur[1]
            end = (x, y)
            points.extend(approx_cubic_bezier(cur, (x1, y1), (x2, y2), end))
            cur = end
            last_cubic_ctrl = (x2, y2)
            last_quad_ctrl = None
            continue

        if op == "Q":
            x1 = next_num()
            y1 = next_num()
            x = next_num()
            y = next_num()
            if not absolute:
                x1 += cur[0]
                y1 += cur[1]
                x += cur[0]
                y += cur[1]
            end = (x, y)
            points.extend(approx_quadratic_bezier(cur, (x1, y1), end))
            cur = end
            last_quad_ctrl = (x1, y1)
            last_cubic_ctrl = None
            continue

        if op == "T":
            x = next_num()
            y = next_num()
            if last_quad_ctrl is None:
                x1, y1 = cur
            else:
                x1 = 2 * cur[0] - last_quad_ctrl[0]
                y1 = 2 * cur[1] - last_quad_ctrl[1]
            if not absolute:
                x += cur[0]
                y += cur[1]
            end = (x, y)
            points.extend(approx_quadratic_bezier(cur, (x1, y1), end))
            cur = end
            last_quad_ctrl = (x1, y1)
            last_cubic_ctrl = None
            continue

        if op == "A":
            rx = next_num()
            ry = next_num()
            rotation = next_num()
            large_arc = int(next_num())
            sweep = int(next_num())
            x = next_num()
            y = next_num()
            if not absolute:
                x += cur[0]
                y += cur[1]
            end = (x, y)
            points.extend(approx_arc_points(cur, rx, ry, rotation, large_arc, sweep, end))
            cur = end
            last_cubic_ctrl = None
            last_quad_ctrl = None
            continue

        break

    if points:
        finish_contour(False)

    return contours


def parse_svg_points(points):
    nums = [float(part) for part in re.findall(r"[-+]?(?:\d*\.\d+|\d+)", points or "")]
    if len(nums) < 4:
        return []
    return [(nums[i], nums[i + 1]) for i in range(0, len(nums) - 1, 2)]


def est_text_width(text, font_px):
    width = 0.0
    for ch in text:
        if ch.isspace():
            width += 0.32
            continue
        if unicodedata.east_asian_width(ch) in {"W", "F"}:
            width += 1.0
            continue
        if ch.isupper():
            width += 0.72
            continue
        if ch.islower():
            width += 0.56
            continue
        if ch.isdigit():
            width += 0.56
            continue
        width += 0.48
    return max(80.0, width * font_px + font_px * 0.8)


def is_bold(weight):
    if weight is None:
        return False
    if str(weight).lower() == "bold":
        return True
    try:
        return int(weight) >= 600
    except ValueError:
        return False


def first_font_family(value):
    if not value:
        return "Microsoft YaHei"
    for family in value.split(","):
        candidate = family.strip().strip("'\"")
        if candidate and candidate.lower() not in {"sans-serif", "serif", "monospace"}:
            return candidate
    return "Microsoft YaHei"


class SvgToEditablePpt:
    def __init__(self, svg_path):
        parser = etree.XMLParser(remove_blank_text=False, recover=True)
        self.root = etree.fromstring(Path(svg_path).read_bytes(), parser)
        self.defs_by_id = {}
        self.css_classes = {}
        self.gradients = {}
        self.gradient_specs = {}
        self.pattern_specs = {}
        self.filter_specs = {}
        self.has_explicit_background = False

        self._index_defs()
        self.css_classes = self._collect_css_classes()
        self._collect_gradients()
        self.pattern_specs = self._collect_patterns()
        self.filter_specs = self._collect_filters()
        self.has_explicit_background = self._detect_explicit_background()
        self.bg_color = self._resolve_background_color()

    def _index_defs(self):
        for el in self.root.iter():
            if not isinstance(el.tag, str):
                continue
            el_id = el.get("id")
            if el_id:
                self.defs_by_id[el_id] = el

    def _collect_css_classes(self):
        classes = {}
        for style_node in self.root.findall(f".//{NS}style"):
            css_text = "".join(style_node.itertext())
            css_text = re.sub(r"/\*.*?\*/", "", css_text, flags=re.S)
            for selector_text, body in CSS_RULE_RE.findall(css_text):
                props = parse_style_attr(body)
                for selector in selector_text.split(","):
                    selector = selector.strip()
                    if not selector.startswith("."):
                        continue
                    class_name = selector[1:].strip()
                    if class_name:
                        classes.setdefault(class_name, {}).update(props)
        return classes

    def _collect_gradients(self):
        self.gradients = {}
        self.gradient_specs = {}

        for grad in self.root.findall(f".//{NS}linearGradient"):
            grad_id = grad.get("id")
            if not grad_id:
                continue
            stops = self._parse_gradient_stops(grad)
            if not stops:
                continue
            spec = {
                "kind": "linear",
                "stops": stops,
                "x1": parse_fraction(grad.get("x1"), 0.0),
                "y1": parse_fraction(grad.get("y1"), 0.0),
                "x2": parse_fraction(grad.get("x2"), 1.0),
                "y2": parse_fraction(grad.get("y2"), 0.0),
            }
            self.gradient_specs[grad_id] = spec
            self.gradients[grad_id] = avg_stop_color(stops)

        for grad in self.root.findall(f".//{NS}radialGradient"):
            grad_id = grad.get("id")
            if not grad_id:
                continue
            stops = self._parse_gradient_stops(grad)
            if not stops:
                continue
            spec = {
                "kind": "radial",
                "stops": stops,
                "cx": parse_fraction(grad.get("cx"), 0.5),
                "cy": parse_fraction(grad.get("cy"), 0.5),
                "fx": parse_fraction(grad.get("fx"), parse_fraction(grad.get("cx"), 0.5)),
                "fy": parse_fraction(grad.get("fy"), parse_fraction(grad.get("cy"), 0.5)),
                "r": parse_fraction(grad.get("r"), 0.5),
            }
            self.gradient_specs[grad_id] = spec
            self.gradients[grad_id] = avg_stop_color(stops)

    def _parse_gradient_stops(self, grad):
        stops = []
        for stop in grad.findall(f"{NS}stop"):
            stop_style = parse_style_attr(stop.get("style"))
            stop_color = stop.get("stop-color") or stop_style.get("stop-color")
            rgb, rgba_alpha = parse_rgb_color(stop_color)
            if not rgb:
                continue
            offset = parse_fraction(stop.get("offset"), 0.0)
            opacity = parse_fraction(
                stop.get("stop-opacity") or stop_style.get("stop-opacity"),
                1.0,
            )
            stops.append(
                {
                    "offset": offset,
                    "rgb": rgb,
                    "opacity": clamp01(opacity * rgba_alpha),
                }
            )

        if not stops:
            return []

        stops.sort(key=lambda item: item["offset"])
        if len(stops) == 1:
            clone = dict(stops[0])
            clone["offset"] = 1.0
            stops.append(clone)
        if stops[0]["offset"] > 0.0:
            stops.insert(0, {**stops[0], "offset": 0.0})
        if stops[-1]["offset"] < 1.0:
            stops.append({**stops[-1], "offset": 1.0})
        return stops

    def _collect_patterns(self):
        patterns = {}
        for pattern in self.root.findall(f".//{NS}pattern"):
            pattern_id = pattern.get("id")
            if not pattern_id:
                continue
            path = pattern.find(f"{NS}path")
            if path is None:
                continue
            patterns[pattern_id] = {
                "width": parse_float(pattern.get("width"), 40.0),
                "height": parse_float(pattern.get("height"), 40.0),
                "style": self.resolve_style(path),
            }
        return patterns

    def _collect_filters(self):
        filters = {}
        for filter_node in self.root.findall(f".//{NS}filter"):
            filter_id = filter_node.get("id")
            if not filter_id:
                continue
            blur = filter_node.find(f"{NS}feGaussianBlur")
            if blur is None:
                continue
            filters[filter_id] = {
                "kind": "glow",
                "std_deviation": parse_float(blur.get("stdDeviation"), 6.0),
            }
        return filters

    def _detect_explicit_background(self):
        top_level_nodes = [
            child
            for child in self.root
            if isinstance(child.tag, str) and etree.QName(child).localname != "defs"
        ]
        for child in top_level_nodes:
            if etree.QName(child).localname != "rect":
                continue
            x = parse_float(child.get("x"), 0.0)
            y = parse_float(child.get("y"), 0.0)
            w = parse_float(child.get("width"), 0.0)
            h = parse_float(child.get("height"), 0.0)
            if abs(x) <= 1.0 and abs(y) <= 1.0 and abs(w - SLIDE_W) <= 1.0 and abs(h - SLIDE_H) <= 1.0:
                return True
        return False

    def resolve_style(self, node, inherited=None):
        style = dict(inherited or {})
        for class_name in (node.get("class") or "").split():
            style.update(self.css_classes.get(class_name, {}))
        for key, value in node.attrib.items():
            if key in {"class", "style"}:
                continue
            if "}" in key:
                key = key.rsplit("}", 1)[-1]
            style[key] = value
        style.update(parse_style_attr(node.get("style")))
        return style

    def resolve_paint(self, value):
        text = (value or "").strip()
        if not text or text == "none":
            return None
        if text.startswith("url(#") and text.endswith(")"):
            ref = text[5:-1]
            if ref in self.gradient_specs:
                return {"kind": "gradient", "spec": self.gradient_specs[ref]}
            if ref in self.pattern_specs:
                return {"kind": "pattern", "spec": self.pattern_specs[ref]}
            return None
        rgb, alpha = parse_rgb_color(text)
        if not rgb:
            return None
        return {"kind": "solid", "rgb": rgb, "alpha": alpha}

    def resolve_color(self, fill):
        paint = self.resolve_paint(fill)
        if not paint:
            return None
        if paint["kind"] == "solid":
            return paint["rgb"]
        if paint["kind"] == "gradient":
            return avg_stop_color(paint["spec"]["stops"])
        return None

    def _resolve_background_color(self):
        root_style = parse_style_attr(self.root.get("style"))
        bg_value = root_style.get("background-color") or self.root.get("background-color")
        bg_rgb = self.resolve_color(bg_value)
        if bg_rgb:
            return bg_rgb

        for child in self.root:
            if not isinstance(child.tag, str):
                continue
            if etree.QName(child).localname != "rect":
                continue
            if abs(parse_float(child.get("width"), 0.0) - SLIDE_W) > 1.0:
                continue
            if abs(parse_float(child.get("height"), 0.0) - SLIDE_H) > 1.0:
                continue
            paint = self.resolve_paint(child.get("fill"))
            if paint and paint["kind"] == "gradient":
                return paint["spec"]["stops"][-1]["rgb"]
            if paint and paint["kind"] == "solid":
                return paint["rgb"]

        return (248, 250, 252)

    def build(self, output_path):
        prs = Presentation()
        prs.slide_width = PPT_W
        prs.slide_height = PPT_H
        blank = prs.slide_layouts[6]

        while prs.slides:
            rel_id = prs.slides._sldIdLst[0].rId
            prs.part.drop_rel(rel_id)
            del prs.slides._sldIdLst[0]

        top_level_nodes = [
            child
            for child in self.root
            if isinstance(child.tag, str) and etree.QName(child).localname != "defs"
        ]

        grouped_slides = (
            len(top_level_nodes) > 1
            and all(etree.QName(child).localname == "g" for child in top_level_nodes)
        )

        if grouped_slides:
            for group in top_level_nodes:
                slide = prs.slides.add_slide(blank)
                self.add_background(slide)
                tx, ty = parse_translate(group.get("transform"))
                self.render_children(group, slide, -tx, -ty)
        else:
            slide = prs.slides.add_slide(blank)
            self.add_background(slide)
            for child in top_level_nodes:
                self.render_node(child, slide, 0.0, 0.0)

        prs.save(str(output_path))

    def add_background(self, slide):
        if self.has_explicit_background:
            return
        bg = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.RECTANGLE,
            0,
            0,
            px_to_emu_x(SLIDE_W),
            px_to_emu_y(SLIDE_H),
        )
        bg.fill.solid()
        bg.fill.fore_color.rgb = RGBColor(*self.bg_color)
        bg.line.fill.background()

    def render_children(self, node, slide, offset_x, offset_y):
        tx, ty = parse_translate(node.get("transform"))
        cur_x = offset_x + tx
        cur_y = offset_y + ty
        for child in node:
            if not isinstance(child.tag, str):
                continue
            self.render_node(child, slide, cur_x, cur_y)

    def render_node(self, node, slide, offset_x, offset_y):
        tag = etree.QName(node).localname
        if tag == "g":
            self.render_children(node, slide, offset_x, offset_y)
            return
        if tag == "use":
            href = node.get("href") or node.get("{http://www.w3.org/1999/xlink}href")
            if not href or not href.startswith("#"):
                return
            ref = self.defs_by_id.get(href[1:])
            if ref is None:
                return
            tx, ty = parse_translate(node.get("transform"))
            if etree.QName(ref).localname == "g":
                self.render_children(ref, slide, offset_x + tx, offset_y + ty)
            else:
                self.render_node(ref, slide, offset_x + tx, offset_y + ty)
            return
        if tag == "rect":
            self.add_rect(slide, node, offset_x, offset_y)
            return
        if tag == "circle":
            self.add_circle(slide, node, offset_x, offset_y)
            return
        if tag == "line":
            style = self.resolve_style(node)
            self._add_styled_line(
                slide,
                parse_float(node.get("x1")) + offset_x,
                parse_float(node.get("y1")) + offset_y,
                parse_float(node.get("x2")) + offset_x,
                parse_float(node.get("y2")) + offset_y,
                style,
                dash=bool(style.get("stroke-dasharray")),
                arrow=bool(style.get("marker-end")),
            )
            return
        if tag == "path":
            self.add_path(slide, node, offset_x, offset_y)
            return
        if tag == "polygon":
            self.add_polygon(slide, node, offset_x, offset_y)
            return
        if tag == "polyline":
            self.add_polyline(slide, node, offset_x, offset_y)
            return
        if tag == "text":
            self.add_text(slide, node, offset_x, offset_y)

    def _effective_opacity(self, style, key):
        base_opacity = parse_fraction(style.get("opacity"), 1.0)
        specific_opacity = parse_fraction(style.get(key), 1.0)
        return clamp01(base_opacity * specific_opacity)

    def _set_color_alpha(self, color_format, opacity):
        try:
            color_element = color_format._color._xClr
        except AttributeError:
            return
        for child in list(color_element):
            if child.tag == qn("a:alpha"):
                color_element.remove(child)
        if opacity >= 0.999:
            return
        alpha = OxmlElement("a:alpha")
        alpha.set("val", str(int(round(clamp01(opacity) * 100000))))
        color_element.append(alpha)

    def _apply_solid_fill(self, fill_format, rgb, opacity):
        fill_format.solid()
        fill_format.fore_color.rgb = RGBColor(*rgb)
        self._set_color_alpha(fill_format.fore_color, opacity)

    def _build_gradient_stop_list(self, stops, opacity):
        parts = [f"<a:gsLst {nsdecls('a')}>"]
        for stop in stops:
            alpha = clamp01(opacity * stop.get("opacity", 1.0))
            parts.append(f'<a:gs pos="{int(round(stop["offset"] * 100000))}">')
            parts.append(f'<a:srgbClr val="{rgb_to_hex(stop["rgb"])}">')
            if alpha < 0.999:
                parts.append(f'<a:alpha val="{int(round(alpha * 100000))}"/>')
            parts.append("</a:srgbClr>")
            parts.append("</a:gs>")
        parts.append("</a:gsLst>")
        return parse_xml("".join(parts))

    def _svg_linear_gradient_angle(self, gradient_spec):
        dx = gradient_spec["x2"] - gradient_spec["x1"]
        dy = gradient_spec["y2"] - gradient_spec["y1"]
        if abs(dx) < 1e-6 and abs(dy) < 1e-6:
            return 0.0
        return math.degrees(math.atan2(-dy, dx)) % 360.0

    def _build_radial_gradient_path(self, gradient_spec):
        left = int(round((gradient_spec["cx"] - gradient_spec["r"]) * 100000))
        top = int(round((gradient_spec["cy"] - gradient_spec["r"]) * 100000))
        right = int(round((1.0 - (gradient_spec["cx"] + gradient_spec["r"])) * 100000))
        bottom = int(round((1.0 - (gradient_spec["cy"] + gradient_spec["r"])) * 100000))
        xml = (
            f'<a:path {nsdecls("a")} path="circle">'
            f'<a:fillToRect l="{left}" t="{top}" r="{right}" b="{bottom}"/>'
            "</a:path>"
        )
        return parse_xml(xml)

    def _apply_gradient_fill(self, fill_format, gradient_spec, opacity):
        fill_format.gradient()
        grad_fill = fill_format._fill._gradFill

        if grad_fill.gsLst is not None:
            grad_fill.remove(grad_fill.gsLst)
        grad_fill.insert(0, self._build_gradient_stop_list(gradient_spec["stops"], opacity))

        if gradient_spec["kind"] == "linear":
            if grad_fill.path is not None:
                grad_fill.remove(grad_fill.path)
            if grad_fill.lin is None:
                grad_fill.append(parse_xml(f'<a:lin {nsdecls("a")} scaled="0"/>'))
            fill_format.gradient_angle = self._svg_linear_gradient_angle(gradient_spec)
        else:
            if grad_fill.lin is not None:
                grad_fill.remove(grad_fill.lin)
            if grad_fill.path is not None:
                grad_fill.remove(grad_fill.path)
            grad_fill.append(self._build_radial_gradient_path(gradient_spec))

    def style_shape(self, shape, fill=None, stroke=None, stroke_width=1.0, opacity=1.0):
        style = {}
        if fill is not None:
            style["fill"] = fill
        if stroke is not None:
            style["stroke"] = stroke
        style["stroke-width"] = str(stroke_width)
        style["opacity"] = str(opacity)
        self._style_shape_with_style(shape, style)

    def _style_shape_with_style(self, shape, style, skip_fill=False):
        fill_paint = None if skip_fill else self.resolve_paint(style.get("fill"))
        stroke_paint = self.resolve_paint(style.get("stroke"))
        fill_opacity = self._effective_opacity(style, "fill-opacity")
        stroke_opacity = self._effective_opacity(style, "stroke-opacity")
        stroke_width = parse_float(style.get("stroke-width"), 1.0)

        if fill_paint and fill_paint["kind"] == "solid":
            opacity = fill_opacity * fill_paint.get("alpha", 1.0)
            self._apply_solid_fill(shape.fill, fill_paint["rgb"], opacity)
        elif fill_paint and fill_paint["kind"] == "gradient":
            self._apply_gradient_fill(shape.fill, fill_paint["spec"], fill_opacity)
        else:
            shape.fill.background()

        if stroke_paint and stroke_paint["kind"] == "solid":
            opacity = stroke_opacity * stroke_paint.get("alpha", 1.0)
            shape.line.fill.solid()
            shape.line.fill.fore_color.rgb = RGBColor(*stroke_paint["rgb"])
            self._set_color_alpha(shape.line.fill.fore_color, opacity)
            shape.line.width = Pt(px_to_pt(stroke_width))
        elif stroke_paint and stroke_paint["kind"] == "gradient":
            self._apply_gradient_fill(shape.line.fill, stroke_paint["spec"], stroke_opacity)
            shape.line.width = Pt(px_to_pt(stroke_width))
        else:
            shape.line.fill.background()

        if style.get("stroke-dasharray"):
            shape.line.dash_style = MSO_LINE_DASH_STYLE.DASH

    def _render_pattern_fill(self, slide, node, pattern, offset_x, offset_y):
        path_style = pattern["style"]
        line_paint = self.resolve_paint(path_style.get("stroke"))
        if not line_paint or line_paint["kind"] != "solid":
            return False

        x = parse_float(node.get("x")) + offset_x
        y = parse_float(node.get("y")) + offset_y
        width = parse_float(node.get("width"))
        height = parse_float(node.get("height"))
        step_x = max(1.0, pattern["width"])
        step_y = max(1.0, pattern["height"])
        opacity = self._effective_opacity(path_style, "stroke-opacity") * line_paint.get("alpha", 1.0)
        stroke_width = parse_float(path_style.get("stroke-width"), 1.0)

        line_x = x
        while line_x <= x + width + 0.5:
            line = slide.shapes.add_connector(
                MSO_CONNECTOR_TYPE.STRAIGHT,
                px_to_emu_x(line_x),
                px_to_emu_y(y),
                px_to_emu_x(line_x),
                px_to_emu_y(y + height),
            )
            self._apply_solid_fill(line.line.fill, line_paint["rgb"], opacity)
            line.line.width = Pt(px_to_pt(stroke_width))
            line_x += step_x

        line_y = y
        while line_y <= y + height + 0.5:
            line = slide.shapes.add_connector(
                MSO_CONNECTOR_TYPE.STRAIGHT,
                px_to_emu_x(x),
                px_to_emu_y(line_y),
                px_to_emu_x(x + width),
                px_to_emu_y(line_y),
            )
            self._apply_solid_fill(line.line.fill, line_paint["rgb"], opacity)
            line.line.width = Pt(px_to_pt(stroke_width))
            line_y += step_y

        return True

    def _glow_color(self, style):
        for key in ("stroke", "fill"):
            paint = self.resolve_paint(style.get(key))
            if not paint:
                continue
            if paint["kind"] == "solid":
                return paint["rgb"]
            if paint["kind"] == "gradient":
                return avg_stop_color(paint["spec"]["stops"])
        return None

    def _apply_glow(self, shape, style):
        filter_ref = (style.get("filter") or "").strip()
        if not filter_ref.startswith("url(#") or not filter_ref.endswith(")"):
            return
        filter_id = filter_ref[5:-1]
        filter_spec = self.filter_specs.get(filter_id)
        if not filter_spec or filter_spec["kind"] != "glow":
            return
        rgb = self._glow_color(style)
        if not rgb:
            return
        radius = max(1, px_to_emu_x(filter_spec["std_deviation"] * 2.0))
        alpha = int(round(self._effective_opacity(style, "stroke-opacity") * 45000))
        sp_pr = shape.element.spPr
        effect_lst = sp_pr.get_or_add_effectLst()
        for child in list(effect_lst):
            if child.tag == qn("a:glow"):
                effect_lst.remove(child)
        glow_xml = (
            f'<a:glow {nsdecls("a")} rad="{radius}">'
            f'<a:srgbClr val="{rgb_to_hex(rgb)}"><a:alpha val="{alpha}"/></a:srgbClr>'
            "</a:glow>"
        )
        effect_lst.append(parse_xml(glow_xml))

    def add_rect(self, slide, node, offset_x, offset_y):
        style = self.resolve_style(node)
        fill_paint = self.resolve_paint(style.get("fill"))
        pattern_rendered = False
        if fill_paint and fill_paint["kind"] == "pattern":
            pattern_rendered = self._render_pattern_fill(slide, node, fill_paint["spec"], offset_x, offset_y)

        if pattern_rendered and not style.get("stroke"):
            return

        x = parse_float(node.get("x")) + offset_x
        y = parse_float(node.get("y")) + offset_y
        w = parse_float(node.get("width"))
        h = parse_float(node.get("height"))
        rx = parse_float(node.get("rx"), parse_float(node.get("ry"), 0.0))
        shape = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE if rx > 0 else MSO_AUTO_SHAPE_TYPE.RECTANGLE,
            px_to_emu_x(x),
            px_to_emu_y(y),
            px_to_emu_x(w),
            px_to_emu_y(h),
        )
        self._style_shape_with_style(shape, style, skip_fill=pattern_rendered)
        if rx > 0:
            shape.adjustments[0] = clamp((rx * 2.0) / max(min(w, h), 1.0), 0.0, 0.5)
        self._apply_glow(shape, style)

    def add_circle(self, slide, node, offset_x, offset_y):
        style = self.resolve_style(node)
        cx = parse_float(node.get("cx")) + offset_x
        cy = parse_float(node.get("cy")) + offset_y
        r = parse_float(node.get("r"))
        shape = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.OVAL,
            px_to_emu_x(cx - r),
            px_to_emu_y(cy - r),
            px_to_emu_x(r * 2.0),
            px_to_emu_y(r * 2.0),
        )
        self._style_shape_with_style(shape, style)
        self._apply_glow(shape, style)

    def _add_styled_line(self, slide, x1, y1, x2, y2, style, dash=False, arrow=False):
        line = slide.shapes.add_connector(
            MSO_CONNECTOR_TYPE.STRAIGHT,
            px_to_emu_x(x1),
            px_to_emu_y(y1),
            px_to_emu_x(x2),
            px_to_emu_y(y2),
        )
        stroke_paint = self.resolve_paint(style.get("stroke"))
        stroke_width = parse_float(style.get("stroke-width"), 1.0)
        stroke_opacity = self._effective_opacity(style, "stroke-opacity")

        if stroke_paint and stroke_paint["kind"] == "solid":
            opacity = stroke_opacity * stroke_paint.get("alpha", 1.0)
            self._apply_solid_fill(line.line.fill, stroke_paint["rgb"], opacity)
        elif stroke_paint and stroke_paint["kind"] == "gradient":
            self._apply_gradient_fill(line.line.fill, stroke_paint["spec"], stroke_opacity)
        else:
            self._apply_solid_fill(line.line.fill, (37, 99, 235), 1.0)

        line.line.width = Pt(px_to_pt(stroke_width))
        if dash:
            line.line.dash_style = MSO_LINE_DASH_STYLE.DASH
        self._apply_glow(line, style)

        if arrow:
            rgb = self._glow_color(style) or (37, 99, 235)
            self.add_arrowhead(slide, x1, y1, x2, y2, rgb, stroke_width)

    def add_arrowhead(self, slide, x1, y1, x2, y2, rgb, stroke_width):
        dx = x2 - x1
        dy = y2 - y1
        angle = math.degrees(math.atan2(dy, dx))
        length = max(16.0, stroke_width * 4.2)
        width = max(12.0, stroke_width * 3.2)
        dist = math.hypot(dx, dy) or 1.0
        ux = dx / dist
        uy = dy / dist
        cx = x2 - ux * (length * 0.35)
        cy = y2 - uy * (length * 0.35)
        triangle = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ISOSCELES_TRIANGLE,
            px_to_emu_x(cx - length / 2.0),
            px_to_emu_y(cy - width / 2.0),
            px_to_emu_x(length),
            px_to_emu_y(width),
        )
        triangle.rotation = angle + 90.0
        triangle.fill.solid()
        triangle.fill.fore_color.rgb = RGBColor(*rgb)
        triangle.line.fill.background()

    def add_path(self, slide, node, offset_x, offset_y):
        style = self.resolve_style(node)
        contours = parse_svg_path(node.get("d"))
        if not contours:
            line = parse_path_line(node.get("d"))
            if not line:
                return
            x1, y1, x2, y2 = line
            self._add_styled_line(
                slide,
                x1 + offset_x,
                y1 + offset_y,
                x2 + offset_x,
                y2 + offset_y,
                style,
                dash=bool(style.get("stroke-dasharray")),
                arrow=bool(style.get("marker-end")),
            )
            return

        shifted = []
        for contour in contours:
            shifted.append(
                {
                    "closed": contour["closed"],
                    "points": [(x + offset_x, y + offset_y) for x, y in contour["points"]],
                }
            )

        shape = self.add_freeform(
            slide,
            shifted,
            fill=None,
            stroke=None,
            stroke_width=parse_float(style.get("stroke-width"), 1.0),
            opacity=1.0,
            dash=bool(style.get("stroke-dasharray")),
            arrow=False,
        )
        if shape is None:
            return
        self._style_shape_with_style(shape, style)
        self._apply_glow(shape, style)

        if style.get("marker-end"):
            points = shifted[-1]["points"]
            if len(points) >= 2:
                (x1, y1), (x2, y2) = points[-2:]
                rgb = self._glow_color(style) or (37, 99, 235)
                self.add_arrowhead(slide, x1, y1, x2, y2, rgb, parse_float(style.get("stroke-width"), 1.0))

    def add_polygon(self, slide, node, offset_x, offset_y):
        style = self.resolve_style(node)
        points = parse_svg_points(node.get("points"))
        if len(points) < 2:
            return
        shape = self.add_freeform(
            slide,
            [{"points": [(x + offset_x, y + offset_y) for x, y in points], "closed": True}],
            fill=None,
            stroke=None,
            stroke_width=parse_float(style.get("stroke-width"), 1.0),
            opacity=1.0,
            dash=bool(style.get("stroke-dasharray")),
        )
        if shape is None:
            return
        self._style_shape_with_style(shape, style)
        self._apply_glow(shape, style)

    def add_polyline(self, slide, node, offset_x, offset_y):
        style = self.resolve_style(node)
        points = parse_svg_points(node.get("points"))
        if len(points) < 2:
            return
        shape = self.add_freeform(
            slide,
            [{"points": [(x + offset_x, y + offset_y) for x, y in points], "closed": False}],
            fill=None,
            stroke=None,
            stroke_width=parse_float(style.get("stroke-width"), 1.0),
            opacity=1.0,
            dash=bool(style.get("stroke-dasharray")),
            arrow=bool(style.get("marker-end")),
        )
        if shape is None:
            return
        self._style_shape_with_style(shape, style)
        self._apply_glow(shape, style)

    def add_freeform(self, slide, contours, fill, stroke, stroke_width, opacity=1.0, dash=False, arrow=False):
        usable = []
        for contour in contours:
            points = contour.get("points", [])
            if len(points) > 1:
                usable.append({"points": points, "closed": contour.get("closed", False)})
        if not usable:
            return None

        first = usable[0]
        start_x, start_y = first["points"][0]
        builder = slide.shapes.build_freeform(
            start_x=start_x,
            start_y=start_y,
            scale=(EMU_PER_PX_X, EMU_PER_PX_Y),
        )
        builder.add_line_segments(first["points"][1:], close=first["closed"])

        for contour in usable[1:]:
            points = contour["points"]
            builder.move_to(points[0][0], points[0][1])
            builder.add_line_segments(points[1:], close=contour["closed"])

        shape = builder.convert_to_shape()
        if fill is not None or stroke is not None:
            self.style_shape(shape, fill=fill, stroke=stroke, stroke_width=stroke_width, opacity=opacity)
        if dash:
            shape.line.dash_style = MSO_LINE_DASH_STYLE.DASH
        if arrow and len(usable[-1]["points"]) >= 2:
            (x1, y1), (x2, y2) = usable[-1]["points"][-2:]
            rgb = self.resolve_color(stroke) or (37, 99, 235)
            self.add_arrowhead(slide, x1, y1, x2, y2, rgb, stroke_width)
        return shape

    def collect_text_runs(self, node):
        runs = []
        base_style = self.resolve_style(node)

        leading = normalize_text(node.text)
        if leading:
            runs.append((leading, base_style))

        for child in node:
            if not isinstance(child.tag, str):
                continue
            if etree.QName(child).localname != "tspan":
                continue
            child_style = self.resolve_style(child, inherited=base_style)
            child_text = normalize_text(child.text)
            if child_text:
                runs.append((child_text, child_style))
            tail = normalize_text(child.tail)
            if tail:
                runs.append((tail, base_style))
        return runs

    def add_text(self, slide, node, offset_x, offset_y):
        runs = self.collect_text_runs(node)
        if not runs:
            return

        node_style = self.resolve_style(node)
        full_text = "".join(text for text, _ in runs)
        x = parse_float(node.get("x")) + offset_x
        y = parse_float(node.get("y")) + offset_y
        font_px = parse_float(node_style.get("font-size"), 20.0)
        est_width = est_text_width(full_text, font_px)
        anchor = (node_style.get("text-anchor") or "start").lower()

        if anchor == "middle":
            max_width = min((x - 24.0) * 2.0, (SLIDE_W - x - 24.0) * 2.0, SLIDE_W - 48.0)
            width = clamp(max(est_width, font_px * 3.0), 80.0, max_width)
            left = x - width / 2.0
            align = PP_ALIGN.CENTER
        elif anchor == "end":
            max_width = max(80.0, x - 24.0)
            width = clamp(max(est_width, font_px * 3.0), 80.0, max_width)
            left = x - width
            align = PP_ALIGN.RIGHT
        else:
            max_width = max(80.0, SLIDE_W - x - 24.0)
            width = clamp(max(est_width, font_px * 3.0), 80.0, max_width)
            left = x
            align = PP_ALIGN.LEFT

        top = max(0.0, y - font_px * 1.05)
        height = max(font_px * 1.5, font_px + 16.0)
        box = slide.shapes.add_textbox(
            px_to_emu_x(left),
            px_to_emu_y(top),
            px_to_emu_x(width),
            px_to_emu_y(height),
        )
        box.fill.background()
        box.line.fill.background()

        frame = box.text_frame
        frame.word_wrap = False
        frame.margin_left = 0
        frame.margin_right = 0
        frame.margin_top = 0
        frame.margin_bottom = 0
        frame.vertical_anchor = MSO_ANCHOR.TOP

        paragraph = frame.paragraphs[0]
        paragraph.alignment = align
        paragraph.clear()

        for text, style in runs:
            run = paragraph.add_run()
            run.text = text
            font = run.font
            font.name = first_font_family(style.get("font-family"))
            font.size = Pt(px_to_pt(parse_float(style.get("font-size"), font_px)))
            paint = self.resolve_paint(style.get("fill"))
            rgb = (15, 23, 42)
            opacity = self._effective_opacity(style, "fill-opacity")
            if paint and paint["kind"] == "solid":
                rgb = paint["rgb"]
                opacity *= paint.get("alpha", 1.0)
            elif paint and paint["kind"] == "gradient":
                rgb = avg_stop_color(paint["spec"]["stops"])
            font.color.rgb = RGBColor(*rgb)
            self._set_color_alpha(font.color, opacity)
            font.bold = is_bold(style.get("font-weight"))


EnhancedSvgToEditablePpt = SvgToEditablePpt


def main():
    parser = argparse.ArgumentParser(description="Convert SVG slides into closer-fidelity editable PPT.")
    parser.add_argument("input_svg", help="Input SVG or SVG-like text file")
    parser.add_argument("output_pptx", help="Output PPTX path")
    args = parser.parse_args()

    converter = SvgToEditablePpt(args.input_svg)
    converter.build(args.output_pptx)


if __name__ == "__main__":
    main()
