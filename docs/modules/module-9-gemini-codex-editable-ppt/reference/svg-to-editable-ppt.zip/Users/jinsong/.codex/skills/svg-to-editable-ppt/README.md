# SVG to Editable PPT

Convert slide-style SVG into an editable PowerPoint deck made of shapes and text boxes.

## When to use

- AI Studio or design-tool exports saved as `.svg`
- `.txt` files whose contents are actually SVG markup
- One-off slide conversion
- Converting a generated SVG page before inserting it into an existing deck

## Quick start

Run:

`python3 scripts/svg_to_editable_ppt.py <input_svg> <output_pptx>`

Example:

`python3 scripts/svg_to_editable_ppt.py ai_studio_code-added2.txt ai_studio_code-added2-editable.pptx`

## Example input

Input file:

`ai_studio_code-added2.txt`

Detected as:

`SVG Scalable Vector Graphics image`

The file may still use a `.txt` suffix as long as it contains `<svg ...>` markup.

## Example output

Output file:

`ai_studio_code-added2-editable.pptx`

Expected result:

- `1` slide
- Dozens of editable shapes and text boxes
- Text remains editable in PowerPoint
- Layout is based on the original `1920x1080` SVG canvas

## Validation

Use a quick structural check:

```sh
python3 - <<'PY'
from pptx import Presentation
prs = Presentation('ai_studio_code-added2-editable.pptx')
print('slides', len(prs.slides))
print('shapes', len(prs.slides[0].shapes) if prs.slides else 0)
PY
```

## Notes

- Best for slide-like SVG, not illustration-heavy SVG art
- Gradients are approximated to solid average colors
- Advanced SVG effects are only partially preserved
- If every drawable top-level node is a `<g>`, each group becomes one slide
- Otherwise the SVG is rendered as a single slide
