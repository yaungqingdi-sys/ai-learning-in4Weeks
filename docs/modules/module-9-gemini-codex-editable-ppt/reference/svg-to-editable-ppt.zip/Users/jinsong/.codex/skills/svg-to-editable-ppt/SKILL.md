---
name: svg-to-editable-ppt
description: Convert SVG or SVG-like text files into editable PPT/PPTX using a bundled Python script. The bundled converter preserves editable shapes/text while supporting common slide-style SVG styling such as CSS class-based text styles, transparency, linear gradients, radial background gradients, grid patterns, and glow approximations. Use when the user wants an AI Studio SVG, an exported SVG page, or an SVG-like .txt file turned into editable PowerPoint shapes and text instead of a flat image. Also use when the user asks for “SVG 转可编辑PPT”, “SVG转PPT”, “svg转ppt”, “把 svg 变成可编辑的 ppt”, or similar Chinese phrasing.
---

# SVG to Editable PPT

Use this skill when a user wants one or more SVG slides converted into an editable PowerPoint deck.

Common Chinese trigger phrases:

- `SVG 转可编辑PPT`
- `SVG转PPT`
- `svg转ppt`
- `把 svg 变成可编辑的 ppt`
- `把 ai studio 导出的 svg 转成可编辑 ppt`

## What it handles

- SVG files and SVG-like text files such as `.txt` exports that actually contain `<svg ...>` markup
- Common primitives used in slide-like SVGs: `rect`, `circle`, `line`, `polygon`, `polyline`, `text`, `tspan`, `use`, `g`, and common `path` icons/shapes
- Single-slide SVGs and multi-slide SVGs where each top-level `<g>` represents a slide
- Common slide-style styling: `<style>` class rules, inline `style`, `fill-opacity`, `stroke-opacity`, and `stop-opacity`
- Linear gradients, radial background gradients, grid-like `pattern` fills, and common glow-style `filter` approximations
- Editable PPT output made of PowerPoint shapes and text boxes, not screenshots

## Bundled script

Use the bundled converter script instead of re-implementing the logic:

`python3 scripts/svg_to_editable_ppt.py <input_svg> <output_pptx>`

Example:

`python3 scripts/svg_to_editable_ppt.py ai_studio_code-added2.txt ai_studio_code-added2-editable.pptx`

## Recommended workflow

1. Confirm the source really contains SVG markup. `file` may already identify `.txt` exports as SVG.
2. Run the bundled converter script.
3. Save the output as `*-editable.pptx` unless the user asked for another name.
4. Verify the output opens and contains shapes/text, not only a single embedded image.
5. For style-sensitive slides, spot-check key fidelity points such as gradient backgrounds, highlighted text colors, translucent tags/cards, and glow-accented separators.
6. If the SVG is part of an existing deck, optionally insert the generated slide into that deck afterward.

## Validation

A quick structural check:

```sh
python3 - <<'PY'
from pptx import Presentation
prs = Presentation('output.pptx')
print('slides', len(prs.slides))
print('shapes on first slide', len(prs.slides[0].shapes) if prs.slides else 0)
PY
```

## Notes and limits

- The converter targets slide-style SVGs rather than arbitrary illustration-grade SVG art.
- SVG root `background-color` is respected for slide background when present.
- SVG CSS class styles, transparency, common gradients, and common glow/pattern effects are approximated into editable PowerPoint-native shapes and text rather than rasterized snapshots.
- Linear gradients can be mapped to PowerPoint gradients, and common radial slide backgrounds are approximated with PowerPoint radial-style fills.
- Grid-like `pattern` fills are recreated as editable line objects.
- Common bezier/arc icon paths are approximated into editable freeform shapes; masks, clipping, advanced filters, and illustration-grade SVG effects are still not preserved exactly.
- Top-level `<g>` nodes are treated as separate slides only when all drawable top-level nodes are groups; otherwise the SVG is rendered as a single slide.
- Python dependencies are `python-pptx` and `lxml`.

## Output expectation

The output should be editable in PowerPoint: users can move shapes, edit text, and restyle objects after conversion.
